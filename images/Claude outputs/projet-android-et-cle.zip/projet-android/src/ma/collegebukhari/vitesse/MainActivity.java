package ma.collegebukhari.vitesse;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;
    private volatile boolean fullscreen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new LocalOnlyClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidApp");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/www/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullscreen) applyFullscreen(true);
    }

    @SuppressWarnings("deprecation")
    void applyFullscreen(boolean on) {
        Window w = getWindow();
        View d = w.getDecorView();
        if (on) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        } else {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    // Classes imbriquées statiques (pas de classes internes anonymes : compatibilité D8)
    static class LocalOnlyClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return !request.getUrl().toString().startsWith("file:///android_asset/");
        }
    }

    static class FsTask implements Runnable {
        private final MainActivity act; private final boolean on;
        FsTask(MainActivity act, boolean on) { this.act = act; this.on = on; }
        @Override public void run() { act.applyFullscreen(on); }
    }

    public static class Bridge {
        private final MainActivity act;
        Bridge(MainActivity act) { this.act = act; }

        @JavascriptInterface
        public boolean toggleFullscreen() {
            act.fullscreen = !act.fullscreen;
            boolean on = act.fullscreen;
            act.runOnUiThread(new FsTask(act, on));
            return on;
        }

        @JavascriptInterface
        public boolean isFullscreen() { return act.fullscreen; }
    }

    @SuppressWarnings("rawtypes")
    static class BackCallback implements ValueCallback {
        private final MainActivity act;
        BackCallback(MainActivity act) { this.act = act; }
        @Override public void onReceiveValue(Object value) {
            if (!"true".equals(value)) act.finish();
        }
    }

    @Override
    public void onBackPressed() {
        evalBack();
    }

    @SuppressWarnings("unchecked")
    private void evalBack() {
        web.evaluateJavascript("(window.appBack ? window.appBack() : false)", new BackCallback(this));
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
