#!/bin/bash
# Construit MouvementVitesse.apk à partir du dossier ../site
set -e
cd "$(dirname "$0")"
T=/tmp/claude-0/-home-claude/f4a965c4-b0ca-5bd9-bb4b-ae533c1687cf/scratchpad/tools
rm -rf build && mkdir -p build/compiled build/classes build/dex build/assets/www
cp -r ../site/. build/assets/www/
rm -f build/assets/www/sw.js build/assets/www/MouvementVitesse.apk
$T/linux/aapt2 compile --dir res -o build/compiled/res.zip
$T/linux/aapt2 link -o build/unsigned.apk -I $T/android.jar --manifest AndroidManifest.xml -A build/assets --auto-add-overlay build/compiled/res.zip --java build/gen --min-sdk-version 21 --target-sdk-version 30 --version-code 1 --version-name 1.0 -0 png -0 jpg
javac -nowarn -source 8 -target 8 -bootclasspath $T/android.jar -d build/classes build/gen/ma/collegebukhari/vitesse/R.java src/ma/collegebukhari/vitesse/MainActivity.java 2>&1 | grep -v "warning" || true
java -cp $T/bundletool.jar com.android.tools.r8.D8 --release --min-api 21 --lib $T/android.jar --output build/dex $(find build/classes -name '*.class')
python3 - <<'PY'
import zipfile
src=zipfile.ZipFile('build/unsigned.apk')
out=zipfile.ZipFile('build/aligned.apk','w')
def add(info,data):
    zi=zipfile.ZipInfo(info.filename if hasattr(info,'filename') else info, date_time=(2026,1,1,0,0,0))
    store = zi.filename=='resources.arsc' or zi.filename.endswith(('.png','.jpg'))
    zi.compress_type = zipfile.ZIP_STORED if store else zipfile.ZIP_DEFLATED
    if store:
        hdr = 30 + len(zi.filename.encode())
        pad = (4 - (out.fp.tell() + hdr) % 4) % 4
        zi.extra = b'\x00'*pad
    out.writestr(zi,data)
for i in src.infolist(): add(i, src.read(i))
add('classes.dex', open('build/dex/classes.dex','rb').read())
out.close()
PY
javac -cp $T/bundletool.jar -d build/signer signer/Sign.java
java -cp $T/bundletool.jar:build/signer Sign keystore/mouvement-vitesse.p12 "$(cat keystore/password.txt)" vitesse build/aligned.apk MouvementVitesse.apk
