package ma.collegebukhari.qcm3ac;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/* Application QCM 3AC : affiche la page (dossier assets/www) dans un WebView.
   Classes imbriquées statiques uniquement (compatibilité de l'outil D8). */
public class MainActivity extends Activity {
    WebView web;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true); // envoi des notes vers la feuille Google depuis la page locale
        s.setSupportZoom(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new Client(this));
        web.addJavascriptInterface(new Bridge(this), "Android");
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    void openExternal(String url) {
        try {
            Intent i = url.startsWith("mailto:") ? new Intent(Intent.ACTION_SENDTO, Uri.parse(url)) : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) { /* aucune application pour ce lien */ }
    }

    static class Client extends WebViewClient {
        private final MainActivity act;
        Client(MainActivity act) { this.act = act; }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();
            if (url.startsWith("file:///android_asset/")) return false;
            act.openExternal(url);
            return true;
        }
    }

    /* Appelé par la page : Android.savePdf(nom, base64) → enregistre le PDF dans Téléchargements */
    public static class Bridge {
        private final MainActivity act;
        Bridge(MainActivity act) { this.act = act; }

        @JavascriptInterface
        public String savePdf(String name, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentResolver r = act.getContentResolver();
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "ERREUR : enregistrement refusé";
                    OutputStream os = r.openOutputStream(uri);
                    os.write(data);
                    os.close();
                    return "Téléchargements/" + name;
                }
                File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, name);
                FileOutputStream os = new FileOutputStream(f);
                os.write(data);
                os.close();
                return f.getAbsolutePath();
            } catch (Exception e) {
                return "ERREUR : " + e.getMessage();
            }
        }
    }

    /* Bouton retour : revient à l'écran précédent de la page ; pendant un quiz noté, il ne fait rien */
    static final String BACK_JS = "(function(){var z=document.querySelector('.zoom');if(z){z.remove();return true}"
        + "try{if(localStorage.getItem('lq-run'))return true}catch(e){}"
        + "var b=document.getElementById('back')||document.getElementById('menu')||document.getElementById('home');"
        + "if(b){b.click();return true}return false})()";

    @SuppressWarnings("rawtypes")
    static class BackCallback implements ValueCallback {
        private final MainActivity act;
        BackCallback(MainActivity act) { this.act = act; }
        @Override public void onReceiveValue(Object value) {
            if (!"true".equals(value)) act.finish();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void onBackPressed() {
        web.evaluateJavascript(BACK_JS, new BackCallback(this));
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
