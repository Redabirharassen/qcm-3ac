// Mise en cache pour un fonctionnement hors ligne (site GitHub Pages)
// Après une modification des questions, augmenter le numéro de version ci-dessous.
const CACHE = 'mouvement-vitesse-v1';
const FILES = [
  "./",
  "index.html",
  "style.css",
  "script.js",
  "questions.js",
  "manifest.webmanifest",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "images/calcul_temps_trajet.png",
  "images/chronometre.png",
  "images/comparaison_vitesses_impact.png",
  "images/compteur_vitesse.png",
  "images/conducteur_fatigue.png",
  "images/conversion_kmh_ms.png",
  "images/crash_test.jpg",
  "images/distance_reaction_freinage.png",
  "images/fleche_distance.png",
  "images/formule_vitesse.png",
  "images/graphe_distance_arret.png",
  "images/graphe_distance_temps.svg",
  "images/panneau_interdistance.png",
  "images/panneau_limitation_50.png",
  "images/pieton_traverse.png",
  "images/pneus_lisses.png",
  "images/route_descente_panneau.svg",
  "images/telephone_volant.png",
  "images/train_gare.svg",
  "images/velo_descente.jpg",
  "images/voiture_pluie.jpg"
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }))
  );
});
