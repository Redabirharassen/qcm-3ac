/* =========================================================================
   Mouvement et Vitesse — logique de l'application
   ========================================================================= */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const LEVEL_NAMES = { facile: 'Facile', moyenne: 'Moyen', difficile: 'Difficile' };
  const LETTERS = ['A', 'B', 'C', 'D', 'E', 'F'];
  const IS_APP = typeof window.AndroidApp !== 'undefined';

  // ---------- Stockage local (protégé : peut être indisponible) ----------
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignoré */ } },
  };

  // ---------- État ----------
  const settings = Object.assign({ level: 'facile', count: 10, timer: 0, name: '' }, store.get('mv-settings', {}));
  let quiz = null;      // { level, items: [...], index, answers: [], start, timeLimit, ended }
  let timerId = null;

  // ---------- Écrans ----------
  function show(screenId) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('active', s.id === screenId));
    window.scrollTo(0, 0);
  }

  function toast(msg) {
    const t = $('toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toast._id);
    toast._id = setTimeout(() => { t.hidden = true; }, 2200);
  }

  // ---------- Accueil ----------
  function renderHome() {
    document.querySelectorAll('.level').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.level === settings.level)));
    document.querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-checked', String(Number(b.dataset.count) === settings.count)));
    $('timer-select').value = String(settings.timer);
    const best = store.get('mv-best', {});
    document.querySelectorAll('[data-best]').forEach((el) => {
      const b = best[el.dataset.best];
      el.textContent = b ? 'Record : ' + b + ' %' : '40 questions';
    });
    // Lien de téléchargement de l'APK : seulement sur le site web
    $('apk-link').hidden = IS_APP || location.protocol === 'file:';
  }

  document.querySelectorAll('.level').forEach((b) => b.addEventListener('click', () => {
    settings.level = b.dataset.level; renderHome();
  }));
  document.querySelectorAll('.chip').forEach((b) => b.addEventListener('click', () => {
    settings.count = Number(b.dataset.count); renderHome();
  }));
  $('student-name').value = settings.name || '';
  $('student-name').addEventListener('input', (e) => { settings.name = e.target.value.trim(); });
  $('timer-select').addEventListener('change', (e) => { settings.timer = Number(e.target.value); });

  // ---------- Préparation des questions ----------
  // Les exercices de synthèse forment un bloc : leurs questions restent ensemble et dans l'ordre.
  function buildItems(level, count) {
    const blocks = QUIZ[level].map((entry, i) => {
      if (entry.type === 'synthese') {
        return entry.questions.map((q, k) => Object.assign({}, q, {
          contexte: entry.contexte, ctxImg: entry.img || null,
          part: k + 1, parts: entry.questions.length, uid: level + '-' + i + '-' + k,
        }));
      }
      return [Object.assign({}, entry, { uid: level + '-' + i })];
    });
    shuffleArray(blocks);
    const chosen = [];
    let total = 0;
    for (const b of blocks) {
      if (total >= count) break;
      if (total + b.length <= count) { chosen.push(b); total += b.length; }
    }
    // Si on n'a pas exactement le nombre demandé, compléter avec des questions isolées restantes
    if (total < count) {
      for (const b of blocks) {
        if (total >= count) break;
        if (!chosen.includes(b) && b.length === 1) { chosen.push(b); total += 1; }
      }
    }
    return chosen.flat().map(prepareItem);
  }

  function prepareItem(q) {
    const item = Object.assign({}, q);
    if (q.type === 'qcm') item.shuffled = shuffleArray(q.options.slice());
    return item;
  }

  // ---------- Démarrage ----------
  function startQuiz(items, level) {
    clearInterval(timerId);
    quiz = {
      level, items, index: 0, answers: new Array(items.length).fill(null),
      start: Date.now(), timeLimit: settings.timer, ended: false,
    };
    $('q-level').textContent = 'Niveau ' + LEVEL_NAMES[level].toLowerCase();
    show('screen-quiz');
    startTimer();
    renderQuestion();
  }

  $('start-btn').addEventListener('click', () => {
    settings.name = $('student-name').value.trim();
    store.set('mv-settings', settings);
    startQuiz(buildItems(settings.level, settings.count), settings.level);
  });

  // ---------- Chronomètre ----------
  function startTimer() {
    const el = $('timer');
    if (!quiz.timeLimit) { el.hidden = true; return; }
    el.hidden = false;
    const tick = () => {
      const left = Math.max(0, quiz.timeLimit - Math.floor((Date.now() - quiz.start) / 1000));
      el.textContent = '⏱ ' + fmt(left);
      el.classList.toggle('low', left <= 30);
      if (left <= 0) { clearInterval(timerId); toast('Temps écoulé !'); endQuiz(true); }
    };
    tick();
    timerId = setInterval(tick, 1000);
  }
  function fmt(s) { return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }

  // ---------- Affichage d'une question ----------
  let selected = null;
  let answered = false;

  function renderQuestion() {
    const q = quiz.items[quiz.index];
    const n = quiz.items.length;
    selected = null; answered = false;

    $('q-counter').textContent = 'Question ' + (quiz.index + 1) + ' / ' + n;
    $('progress-fill').style.width = (quiz.index / n * 100) + '%';

    // Contexte (exercice de synthèse)
    if (q.contexte) {
      $('context-box').hidden = false;
      $('context-tag').textContent = 'Exercice de synthèse · question ' + q.part + '/' + q.parts;
      $('context-text').textContent = q.contexte;
    } else {
      $('context-box').hidden = true;
    }

    // Image
    const img = q.img || q.ctxImg;
    $('q-figure').hidden = !img;
    if (img) $('q-image').src = img;

    $('q-text').textContent = q.q;

    // Réponses
    const opts = $('options');
    opts.innerHTML = '';
    const numArea = $('num-area');
    const input = $('num-input');
    $('feedback').hidden = true;

    if (q.type === 'qcm') {
      numArea.hidden = true;
      q.shuffled.forEach((text, i) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'option';
        b.setAttribute('role', 'radio');
        b.setAttribute('aria-checked', 'false');
        b.dataset.value = text;
        const letter = document.createElement('span');
        letter.className = 'option-letter';
        letter.textContent = LETTERS[i];
        const label = document.createElement('span');
        label.textContent = text;
        b.append(letter, label);
        b.addEventListener('click', () => {
          if (answered) return;
          selected = text;
          opts.querySelectorAll('.option').forEach((o) => o.setAttribute('aria-checked', String(o === b)));
        });
        opts.appendChild(b);
      });
    } else {
      numArea.hidden = false;
      input.value = '';
      input.disabled = false;
      $('num-unit').textContent = q.unit || '';
      input.parentElement.className = 'num-wrap';
      setTimeout(() => input.focus(), 50);
    }

    $('action-btn').textContent = 'Valider';
  }

  // ---------- Correction ----------
  function parseNumber(str) {
    const clean = String(str).replace(/[\s  ]/g, '').replace(/,/g, '.');
    const m = clean.match(/-?\d+(\.\d+)?|-?\.\d+/);
    return m ? parseFloat(m[0]) : NaN;
  }
  function isCloseEnough(user, expected, tol) {
    const t = tol !== undefined ? tol : Math.max(Math.abs(expected) * 0.02, 0.05);
    return Math.abs(user - expected) <= t + 1e-9;
  }
  function fmtNumber(x) { return String(x).replace('.', ','); }

  function validate() {
    const q = quiz.items[quiz.index];
    let correct = false;
    let given = null;

    if (q.type === 'qcm') {
      if (selected === null) { toast('Choisis une réponse.'); return; }
      given = selected;
      correct = selected === q.answer;
      $('options').querySelectorAll('.option').forEach((o) => {
        o.disabled = true;
        if (o.dataset.value === q.answer) o.classList.add('correct');
        else if (o.dataset.value === selected) o.classList.add('wrong');
      });
    } else {
      const raw = $('num-input').value.trim();
      if (!raw) { toast('Écris ta réponse.'); return; }
      const val = parseNumber(raw);
      if (isNaN(val)) { toast('Écris un nombre (ex. : 12,5).'); return; }
      given = fmtNumber(val) + (q.unit ? ' ' + q.unit : '');
      correct = isCloseEnough(val, q.answer, q.tol);
      $('num-input').disabled = true;
      $('num-input').parentElement.classList.add(correct ? 'correct' : 'wrong');
    }

    answered = true;
    quiz.answers[quiz.index] = { given, correct };

    const fb = $('feedback');
    fb.hidden = false;
    fb.className = 'feedback ' + (correct ? 'ok' : 'ko');
    $('feedback-title').textContent = correct ? pick(['Bravo !', 'Exact !', 'Bonne réponse !', 'Très bien !']) : 'Pas tout à fait…';
    $('feedback-answer').textContent = correct ? '' : 'Bonne réponse : ' + answerText(q);
    $('feedback-answer').hidden = correct;
    $('feedback-expl').textContent = q.expl || '';

    $('action-btn').textContent = quiz.index + 1 < quiz.items.length ? 'Question suivante' : 'Voir mes résultats';
    $('progress-fill').style.width = ((quiz.index + 1) / quiz.items.length * 100) + '%';
    fb.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function answerText(q) { return q.type === 'num' ? fmtNumber(q.answer) + (q.unit ? ' ' + q.unit : '') : q.answer; }

  $('action-btn').addEventListener('click', () => {
    if (!quiz || quiz.ended) return;
    if (!answered) { validate(); return; }
    if (quiz.index + 1 < quiz.items.length) { quiz.index++; renderQuestion(); }
    else endQuiz(false);
  });
  $('num-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); $('action-btn').click(); }
  });

  // ---------- Résultats ----------
  function endQuiz(timeUp) {
    if (!quiz || quiz.ended) return;
    quiz.ended = true;
    clearInterval(timerId);

    const n = quiz.items.length;
    const good = quiz.answers.filter((a) => a && a.correct).length;
    const pct = Math.round(good / n * 100);
    const note10 = Math.round(good / n * 100) / 10;

    const ring = $('ring');
    ring.style.setProperty('--p', pct);
    ring.style.setProperty('--c', pct >= 70 ? 'var(--ok)' : pct >= 50 ? 'var(--accent)' : 'var(--ko)');
    $('ring-value').textContent = pct + ' %';

    const who = settings.name ? settings.name + ', ' : '';
    let title;
    if (pct >= 90) title = 'Excellent travail !';
    else if (pct >= 70) title = 'Très bien !';
    else if (pct >= 50) title = 'Assez bien, continue !';
    else title = 'Il faut encore t\'entraîner.';
    $('result-title').textContent = who ? who + title.charAt(0).toLowerCase() + title.slice(1) : title;
    $('result-score').textContent = good + ' / ' + n + ' bonnes réponses · note : ' + fmtNumber(note10) + ' / 10';

    const secs = Math.round((Date.now() - quiz.start) / 1000);
    $('result-time').textContent = (timeUp ? 'Temps écoulé · ' : '') + 'Durée : ' + fmt(secs) + ' · Niveau ' + LEVEL_NAMES[quiz.level].toLowerCase();

    // Record (seulement pour un exercice complet de 10 questions ou plus)
    if (!quiz.isRetry && n >= 10) {
      const best = store.get('mv-best', {});
      if (!best[quiz.level] || pct > best[quiz.level]) { best[quiz.level] = pct; store.set('mv-best', best); }
    }

    // Correction détaillée
    const list = $('review');
    list.innerHTML = '';
    quiz.items.forEach((q, i) => {
      const a = quiz.answers[i];
      const li = document.createElement('li');
      li.className = a && a.correct ? 'ok' : 'ko';
      const parts = [];
      if (q.contexte) parts.push(el('p', 'r-ctx', 'Synthèse : ' + q.contexte));
      parts.push(el('p', 'r-q', (i + 1) + '. ' + q.q));
      parts.push(el('p', 'r-line', 'Ta réponse : ' + (a ? a.given : 'pas de réponse') + (a && a.correct ? ' ✓' : ' ✗')));
      if (!a || !a.correct) parts.push(el('p', 'r-line', 'Bonne réponse : ' + answerText(q)));
      if (q.expl) parts.push(el('p', 'r-expl', q.expl));
      li.append(...parts);
      list.appendChild(li);
    });

    const wrong = quiz.answers.filter((a) => !a || !a.correct).length;
    $('retry-wrong-btn').hidden = wrong === 0;
    $('retry-wrong-btn').textContent = 'Refaire mes erreurs (' + wrong + ')';
    show('screen-results');
  }
  function el(tag, cls, text) { const e = document.createElement(tag); e.className = cls; e.textContent = text; return e; }

  $('retry-wrong-btn').addEventListener('click', () => {
    const items = quiz.items.filter((q, i) => !quiz.answers[i] || !quiz.answers[i].correct).map(prepareItem);
    const level = quiz.level;
    startQuiz(items, level);
    quiz.isRetry = true;
  });
  $('restart-btn').addEventListener('click', () => startQuiz(buildItems(quiz.level, settings.count), quiz.level));
  $('home-btn').addEventListener('click', goHome);

  function goHome() {
    clearInterval(timerId);
    if (quiz) quiz.ended = true;
    renderHome();
    show('screen-home');
  }

  // ---------- Quitter (avec confirmation) ----------
  function askQuit() {
    $('modal').hidden = false;
  }
  $('quit-btn').addEventListener('click', askQuit);
  $('modal-cancel').addEventListener('click', () => { $('modal').hidden = true; });
  $('modal-ok').addEventListener('click', () => { $('modal').hidden = true; goHome(); });

  // ---------- Image agrandie ----------
  $('q-image').addEventListener('click', () => {
    $('lightbox-img').src = $('q-image').src;
    $('lightbox').hidden = false;
  });
  $('lightbox').addEventListener('click', () => { $('lightbox').hidden = true; });

  // ---------- Plein écran ----------
  const ICON_ENTER = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
  const ICON_EXIT = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/></svg>';
  const docEl = document.documentElement;
  const canWebFs = !!(docEl.requestFullscreen || docEl.webkitRequestFullscreen);
  let appFs = false;

  function isFs() {
    if (IS_APP) return appFs;
    return !!(document.fullscreenElement || document.webkitFullscreenElement);
  }
  function refreshFsButtons() {
    document.querySelectorAll('.fs-btn').forEach((b) => {
      b.hidden = !(IS_APP || canWebFs);
      b.innerHTML = isFs() ? ICON_EXIT : ICON_ENTER;
      b.setAttribute('aria-label', isFs() ? 'Quitter le plein écran' : 'Plein écran');
      b.title = b.getAttribute('aria-label');
    });
  }
  function toggleFs() {
    if (IS_APP) {
      try { appFs = !!window.AndroidApp.toggleFullscreen(); } catch (e) { appFs = !appFs; }
      refreshFsButtons();
      return;
    }
    if (isFs()) {
      (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    } else {
      const req = docEl.requestFullscreen || docEl.webkitRequestFullscreen;
      const p = req.call(docEl);
      if (p && p.catch) p.catch(() => toast('Plein écran non disponible ici.'));
    }
  }
  document.querySelectorAll('.fs-btn').forEach((b) => b.addEventListener('click', toggleFs));
  document.addEventListener('fullscreenchange', refreshFsButtons);
  document.addEventListener('webkitfullscreenchange', refreshFsButtons);

  // ---------- Bouton « retour » d'Android (appelé par l'application) ----------
  window.appBack = function () {
    if (!$('lightbox').hidden) { $('lightbox').hidden = true; return true; }
    if (!$('modal').hidden) { $('modal').hidden = true; return true; }
    if ($('screen-quiz').classList.contains('active')) { askQuit(); return true; }
    if ($('screen-results').classList.contains('active')) { goHome(); return true; }
    return false;
  };

  // ---------- Mode hors ligne pour le site web ----------
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }

  // ---------- Initialisation ----------
  renderHome();
  refreshFsButtons();
})();
