# Mouvement et Vitesse — exercices interactifs (3AC)

Application d'entraînement en physique-chimie : vitesse moyenne, conversions km/h ↔ m/s,
distance de réaction, distance de freinage, distance d'arrêt et sécurité routière.

- 3 niveaux (facile, moyen, difficile), **40 questions par niveau**, avec une correction expliquée
- Exercices de synthèse dont les questions restent groupées
- Chronomètre au choix, bouton plein écran, « Refaire mes erreurs »
- Fonctionne sur téléphone et ordinateur, même hors ligne une fois ouvert

**Application Android** : fichier `MouvementVitesse.apk` dans ce dépôt.

Pour ajouter ou modifier des questions : éditer `questions.js` (le mode d'emploi est en haut du fichier),
puis augmenter le numéro de version dans `sw.js` (`mouvement-vitesse-v1` → `v2`).

Collège Al Imam Al Boukhari · Rabat — Prof. Reda Birharassen
