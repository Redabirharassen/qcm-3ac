/* =========================================================================
   Banque de questions — Mouvement et Vitesse (3AC)
   40 questions par niveau (les questions des exercices de synthèse comptent).

   Format d'une question :
     { type: 'qcm', q: "...", options: [...], answer: "...", img?: "images/...", expl: "..." }
     { type: 'num', q: "...", answer: 12.5, unit: "km/h", expl: "..." }
   Format d'un exercice de synthèse (ses questions restent ensemble et dans l'ordre) :
     { type: 'synthese', contexte: "...", img?: "...", questions: [ ...questions... ] }

   Pour ajouter une question : copier une ligne, la modifier, garder la virgule finale.
   Réponses numériques : écrire le nombre avec un POINT (12.5). L'élève peut taper 12,5.
   ========================================================================= */

const QUIZ = {

  /* ======================= NIVEAU FACILE (40) ======================= */
  facile: [
    { type: 'qcm', q: "Quelle est une unité courante de la vitesse ?", options: ["Mètre (m)", "Kilomètre par heure (km/h)", "Seconde (s)", "Newton (N)"], answer: "Kilomètre par heure (km/h)", expl: "Une vitesse est une distance divisée par une durée : km/h ou m/s." },
    { type: 'num', q: "Un véhicule roule à 90 km/h pendant 2 heures. Quelle distance parcourt-il ?", unit: "km", answer: 180, expl: "d = v × t = 90 × 2 = 180 km." },
    { type: 'qcm', q: "La distance d'arrêt est la somme de la distance de réaction et de la distance de…", options: ["Vitesse", "Freinage", "Temps", "Réflexe"], answer: "Freinage", expl: "Distance d'arrêt = distance de réaction + distance de freinage." },
    { type: 'qcm', q: "Qu'est-ce qui influence le plus la distance de freinage ?", options: ["La couleur du véhicule", "La vitesse du véhicule", "Le nombre de passagers", "La musique écoutée"], answer: "La vitesse du véhicule", expl: "Plus la vitesse est grande, plus la distance de freinage est grande." },
    { type: 'num', q: "Un piéton marche à 5 km/h. Combien de temps lui faut-il pour parcourir 10 km ?", unit: "h", answer: 2, expl: "t = d / v = 10 / 5 = 2 h." },
    { type: 'qcm', q: "Quelle formule donne la vitesse v à partir de la distance d et de la durée t ?", options: ["v = d / t", "v = d × t", "v = t / d", "v = d + t"], answer: "v = d / t", expl: "La vitesse moyenne est la distance parcourue divisée par la durée du parcours." },
    { type: 'num', q: "Un cycliste parcourt 30 km en 2 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 15, expl: "v = d / t = 30 / 2 = 15 km/h." },
    { type: 'qcm', q: "Quelle est l'unité internationale (SI) de la distance ?", options: ["Mètre (m)", "Kilogramme (kg)", "Seconde (s)", "Kilomètre (km)"], answer: "Mètre (m)", expl: "Dans le Système International, la distance s'exprime en mètres." },
    { type: 'qcm', q: "Pendant le temps de réaction, le véhicule continue-t-il d'avancer à sa vitesse initiale ?", options: ["Oui", "Non", "Seulement s'il pleut", "Seulement la nuit"], answer: "Oui", expl: "Le conducteur n'a pas encore freiné : la voiture garde sa vitesse." },
    { type: 'num', q: "Un train parcourt 200 km en 4 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 50, expl: "v = 200 / 4 = 50 km/h." },
    { type: 'qcm', q: "Qu'est-ce qui peut augmenter la distance de freinage ?", options: ["Une route sèche", "Des pneus neufs", "La pluie", "Une faible vitesse"], answer: "La pluie", expl: "Sur route mouillée, les pneus adhèrent moins : le freinage est plus long." },
    { type: 'num', q: "Un véhicule roule à 60 km/h. Quelle distance parcourt-il en 30 minutes (0,5 h) ?", unit: "km", answer: 30, expl: "d = 60 × 0,5 = 30 km." },
    { type: 'qcm', q: "Une vitesse plus élevée entraîne généralement…", options: ["Une distance d'arrêt plus courte", "Une distance d'arrêt plus longue", "Une meilleure maîtrise du véhicule", "Moins de risques d'accident"], answer: "Une distance d'arrêt plus longue", expl: "La distance de réaction et la distance de freinage augmentent toutes les deux avec la vitesse." },
    { type: 'num', q: "Un coureur parcourt 100 mètres en 10 secondes. Quelle est sa vitesse ?", unit: "m/s", answer: 10, expl: "v = 100 / 10 = 10 m/s." },
    { type: 'qcm', q: "Si la vitesse double, comment varie la distance parcourue pendant le temps de réaction ?", options: ["Elle reste la même", "Elle double", "Elle quadruple", "Elle diminue de moitié"], answer: "Elle double", expl: "Distance de réaction = v × temps de réaction : elle est proportionnelle à la vitesse." },
    { type: 'num', q: "Un véhicule roule à 120 km/h. Quelle distance parcourt-il en 15 minutes (0,25 h) ?", unit: "km", answer: 30, expl: "d = 120 × 0,25 = 30 km." },
    { type: 'qcm', q: "Respecter les limitations de vitesse permet de…", options: ["Économiser du carburant", "Réduire les distances d'arrêt", "Avoir plus de temps pour réagir", "Toutes ces réponses"], answer: "Toutes ces réponses", expl: "Rouler moins vite a tous ces avantages à la fois." },
    { type: 'num', q: "Un objet se déplace à 10 m/s pendant 5 secondes. Quelle distance parcourt-il ?", unit: "m", answer: 50, expl: "d = 10 × 5 = 50 m." },
    { type: 'qcm', q: "Qu'est-ce qui peut augmenter le temps de réaction d'un conducteur ?", options: ["La fatigue", "L'utilisation du téléphone", "L'alcool", "Toutes ces réponses"], answer: "Toutes ces réponses", expl: "Fatigue, distraction et alcool ralentissent tous la réaction." },
    { type: 'num', q: "Un avion parcourt 900 km en 3 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 300, expl: "v = 900 / 3 = 300 km/h." },
    { type: 'num', q: "Un bus parcourt 120 km en 2 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 60, expl: "v = 120 / 2 = 60 km/h." },
    { type: 'num', q: "Combien y a-t-il de secondes dans une heure ?", unit: "s", answer: 3600, expl: "1 h = 60 min = 60 × 60 s = 3600 s." },
    { type: 'qcm', q: "Un mouvement est dit uniforme lorsque la vitesse…", options: ["Reste constante", "Augmente", "Diminue", "Est nulle"], answer: "Reste constante", expl: "Uniforme = la valeur de la vitesse ne change pas." },
    { type: 'qcm', q: "Un corps est en mouvement par rapport à un objet de référence si…", options: ["Sa position change par rapport à cet objet", "Sa position ne change pas", "Il est lourd", "Il est loin"], answer: "Sa position change par rapport à cet objet", expl: "Le mouvement est toujours défini par rapport à un objet de référence." },
    { type: 'qcm', q: "Un passager est assis dans un bus qui roule. Par rapport au siège du bus, le passager est…", options: ["Au repos", "En mouvement", "En mouvement circulaire", "En chute"], answer: "Au repos", expl: "Sa position ne change pas par rapport au siège : il est au repos par rapport à lui." },
    { type: 'qcm', q: "Le mouvement de la valve d'une roue de vélo, par rapport à l'axe de la roue, est…", options: ["Rectiligne", "Circulaire", "Immobile", "Aléatoire"], answer: "Circulaire", expl: "La valve tourne autour de l'axe en décrivant un cercle." },

    // -- Questions avec image --
    { type: 'qcm', img: 'images/compteur_vitesse.png', q: "Que mesure cet instrument dans une voiture ?", options: ["La distance parcourue", "La vitesse instantanée", "Le temps de trajet", "Le niveau d'essence"], answer: "La vitesse instantanée", expl: "Le compteur de vitesse indique la vitesse à chaque instant." },
    { type: 'qcm', img: 'images/panneau_limitation_50.png', q: "Que signifie ce panneau ?", options: ["Vitesse minimale 50 km/h", "Distance avant la ville 50 km", "Vitesse maximale autorisée 50 km/h", "Route prioritaire sur 50 m"], answer: "Vitesse maximale autorisée 50 km/h", expl: "Un panneau rond à bord rouge avec un nombre indique la vitesse maximale." },
    { type: 'qcm', img: 'images/pieton_traverse.png', q: "Un piéton traverse. Le conducteur doit adapter sa vitesse pour pouvoir…", options: ["Klaxonner fort", "S'arrêter à temps", "Le contourner rapidement", "Accélérer"], answer: "S'arrêter à temps", expl: "Une vitesse adaptée garde une distance d'arrêt suffisante." },
    { type: 'qcm', img: 'images/velo_descente.jpg', q: "Dans cette descente, la vitesse du vélo a tendance à…", options: ["Diminuer naturellement", "Rester constante", "Augmenter naturellement", "Dépendre du vent"], answer: "Augmenter naturellement", expl: "Dans une descente, le poids entraîne le vélo : sa vitesse augmente." },
    { type: 'qcm', img: 'images/train_gare.svg', q: "Un train qui arrive en gare est en phase de…", options: ["Accélération", "Vitesse constante", "Décélération (ralentissement)", "Arrêt complet"], answer: "Décélération (ralentissement)", expl: "Pour s'arrêter au quai, le train ralentit : son mouvement est ralenti." },
    { type: 'qcm', img: 'images/fleche_distance.png', q: "Cette flèche représente une…", options: ["Vitesse", "Durée", "Distance", "Force"], answer: "Distance", expl: "La flèche mesure l'écart entre deux positions : c'est une distance." },
    { type: 'qcm', img: 'images/chronometre.png', q: "Cet instrument mesure une…", options: ["Vitesse", "Distance", "Masse", "Durée (temps)"], answer: "Durée (temps)", expl: "Le chronomètre mesure des durées." },
    { type: 'qcm', img: 'images/crash_test.jpg', q: "Dans ce crash test à 64 km/h, qu'est-ce qui permet au conducteur de survivre ?", options: ["La ceinture de sécurité", "La radio", "Les vitres", "La couleur de la voiture"], answer: "La ceinture de sécurité", expl: "La ceinture retient le corps et l'empêche d'être projeté contre le volant ou le pare-brise." },

    // -- Exercices de synthèse --
    { type: 'synthese', contexte: "Une voiture roule à la vitesse constante de 50 km/h.", questions: [
      { type: 'num', q: "Quelle distance parcourt-elle en 2 heures ?", unit: "km", answer: 100, expl: "d = 50 × 2 = 100 km." },
      { type: 'num', q: "Combien de temps lui faut-il pour parcourir 25 km ?", unit: "h", answer: 0.5, expl: "t = 25 / 50 = 0,5 h (30 min)." },
    ]},
    { type: 'synthese', contexte: "Un enfant court 50 mètres en 10 secondes.", questions: [
      { type: 'num', q: "Quelle est sa vitesse moyenne ?", unit: "m/s", answer: 5, expl: "v = 50 / 10 = 5 m/s." },
      { type: 'qcm', q: "S'il garde cette vitesse, quelle distance parcourt-il en 20 secondes ?", options: ["50 m", "75 m", "100 m", "150 m"], answer: "100 m", expl: "d = 5 × 20 = 100 m." },
    ]},
    { type: 'synthese', contexte: "Ahmed va au collège à vélo. Il parcourt 3 km en 15 minutes (0,25 h).", questions: [
      { type: 'num', q: "Quelle est la vitesse moyenne d'Ahmed ?", unit: "km/h", answer: 12, expl: "v = 3 / 0,25 = 12 km/h." },
      { type: 'qcm', q: "Par rapport à son vélo, Ahmed est…", options: ["Au repos", "En mouvement", "En mouvement circulaire", "On ne peut pas savoir"], answer: "Au repos", expl: "Ahmed ne change pas de position par rapport à son vélo." },
    ]},
  ],

  /* ======================= NIVEAU MOYEN (40) ======================= */
  moyenne: [
    { type: 'qcm', q: "Quelle formule donne la distance d connaissant la vitesse v et la durée t ?", options: ["d = v × t", "d = v / t", "d = t / v", "d = v − t"], answer: "d = v × t", expl: "De v = d / t on tire d = v × t." },
    { type: 'qcm', q: "Sur une route mouillée, la distance de freinage augmente car…", options: ["Le temps de réaction augmente", "L'adhérence des pneus diminue", "La masse du véhicule augmente", "Le conducteur voit moins bien"], answer: "L'adhérence des pneus diminue", expl: "L'eau entre le pneu et la route réduit l'adhérence." },
    { type: 'num', q: "Convertir 108 km/h en m/s.", unit: "m/s", answer: 30, expl: "108 / 3,6 = 30 m/s." },
    { type: 'qcm', q: "Lequel de ces facteurs n'influence PAS le temps de réaction du conducteur ?", options: ["L'état de fatigue", "La consommation d'alcool", "La vitesse du véhicule", "La distraction (téléphone)"], answer: "La vitesse du véhicule", expl: "Le temps de réaction dépend du conducteur ; la vitesse change la distance de réaction, pas le temps." },
    { type: 'num', q: "Un conducteur a un temps de réaction de 1 s. Il roule à 54 km/h (15 m/s). Quelle distance parcourt-il pendant ce temps de réaction ?", unit: "m", answer: 15, expl: "d = 15 × 1 = 15 m." },
    { type: 'qcm', q: "Quelle est l'unité internationale (SI) de la vitesse ?", options: ["Mètre par seconde (m/s)", "Kilomètre par heure (km/h)", "Mètre par seconde au carré (m/s²)", "Kilomètre (km)"], answer: "Mètre par seconde (m/s)", expl: "Mètre (unité SI de distance) divisé par seconde (unité SI de durée)." },
    { type: 'num', q: "Un véhicule roule à 120 km/h. Combien de temps lui faut-il pour parcourir 60 km ?", unit: "h", answer: 0.5, expl: "t = 60 / 120 = 0,5 h." },
    { type: 'qcm', q: "Sur une route verglacée, l'adhérence est très faible. La distance de freinage sera…", options: ["Identique à une route sèche", "Légèrement augmentée", "Fortement augmentée", "Diminuée"], answer: "Fortement augmentée", expl: "Sur le verglas, la distance de freinage peut être plusieurs fois plus grande." },
    { type: 'num', q: "Un objet se déplace à 36 km/h. Quelle est sa vitesse en m/s ?", unit: "m/s", answer: 10, expl: "36 / 3,6 = 10 m/s." },
    { type: 'qcm', q: "La distance parcourue pendant le temps de réaction est proportionnelle à…", options: ["La masse du véhicule", "La vitesse", "L'état des freins", "La météo"], answer: "La vitesse", expl: "Distance de réaction = v × temps de réaction." },
    { type: 'num', q: "Un train parcourt 400 km en 5 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 80, expl: "v = 400 / 5 = 80 km/h." },
    { type: 'qcm', q: "Garder une distance de sécurité suffisante permet surtout…", options: ["D'économiser de l'essence", "D'avoir le temps de réagir et de freiner si le véhicule devant freine brusquement", "De mieux voir les panneaux", "De rouler plus vite"], answer: "D'avoir le temps de réagir et de freiner si le véhicule devant freine brusquement", expl: "La distance de sécurité couvre au moins la distance parcourue pendant la réaction." },
    { type: 'num', q: "Un véhicule roule à 72 km/h. Quelle est sa vitesse en m/s ?", unit: "m/s", answer: 20, expl: "72 / 3,6 = 20 m/s." },
    { type: 'qcm', q: "Si la vitesse d'un véhicule double, sa distance de freinage (sur sol sec) est environ…", options: ["Divisée par 2", "Doublée", "Multipliée par 4", "Inchangée"], answer: "Multipliée par 4", expl: "La distance de freinage est proportionnelle au carré de la vitesse : 2² = 4." },
    { type: 'num', q: "Un cycliste parcourt 45 km en 3 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 15, expl: "v = 45 / 3 = 15 km/h." },
    { type: 'qcm', q: "Dans une descente, à même vitesse initiale, la distance de freinage a tendance à…", options: ["Diminuer grâce au poids", "Augmenter à cause du poids", "Rester la même", "Dépendre de la couleur de la voiture"], answer: "Augmenter à cause du poids", expl: "Dans une descente, le poids entraîne la voiture vers l'avant et s'oppose au freinage." },
    { type: 'num', q: "Un piéton marche à 4 km/h. Combien de temps lui faut-il pour parcourir 2 km ?", unit: "h", answer: 0.5, expl: "t = 2 / 4 = 0,5 h (30 min)." },
    { type: 'qcm', q: "Pour réduire la distance de freinage, la mesure la plus efficace est de…", options: ["Gonfler les pneus", "Réduire sa vitesse", "Appuyer plus fort sur le frein", "Allumer ses phares"], answer: "Réduire sa vitesse", expl: "La distance de freinage dépend du carré de la vitesse : réduire la vitesse a un grand effet." },
    { type: 'num', q: "Un véhicule roule à 90 km/h. Quelle est sa vitesse en m/s ?", unit: "m/s", answer: 25, expl: "90 / 3,6 = 25 m/s." },
    { type: 'qcm', q: "La distance de freinage est proportionnelle au carré de la vitesse. Si la vitesse est multipliée par 3, la distance de freinage est multipliée par…", options: ["3", "6", "9", "27"], answer: "9", expl: "3² = 9." },
    { type: 'num', q: "Convertir 20 m/s en km/h.", unit: "km/h", answer: 72, expl: "20 × 3,6 = 72 km/h." },
    { type: 'num', q: "Un conducteur roule à 20 m/s. Son temps de réaction est de 1,5 s. Quelle est sa distance de réaction ?", unit: "m", answer: 30, expl: "d = 20 × 1,5 = 30 m." },
    { type: 'num', q: "La distance de réaction d'une voiture est 15 m et sa distance de freinage 25 m. Quelle est sa distance d'arrêt ?", unit: "m", answer: 40, expl: "Distance d'arrêt = 15 + 25 = 40 m." },
    { type: 'qcm', q: "Un mouvement est dit accéléré lorsque…", options: ["La vitesse augmente", "La vitesse diminue", "La vitesse reste constante", "Le corps est au repos"], answer: "La vitesse augmente", expl: "Accéléré = la vitesse augmente ; ralenti = elle diminue ; uniforme = elle est constante." },

    // -- Questions avec image --
    { type: 'qcm', img: 'images/voiture_pluie.jpg', q: "Sous la pluie, comment évolue la distance de freinage par rapport à une route sèche ?", options: ["Elle diminue", "Elle reste identique", "Elle augmente", "Elle devient nulle"], answer: "Elle augmente", expl: "La route mouillée réduit l'adhérence des pneus." },
    { type: 'qcm', img: 'images/panneau_interdistance.png', q: "Ce panneau rappelle la distance de sécurité. Cette distance doit être plus grande si…", options: ["Il fait beau", "La vitesse est élevée", "La voiture est neuve", "La route est droite"], answer: "La vitesse est élevée", expl: "Plus on roule vite, plus on parcourt de mètres pendant le temps de réaction." },
    { type: 'qcm', img: 'images/conducteur_fatigue.png', q: "La fatigue du conducteur influence surtout…", options: ["La distance de freinage", "Le temps de réaction", "L'usure des pneus", "La consommation de carburant"], answer: "Le temps de réaction", expl: "Un conducteur fatigué réagit plus lentement." },
    { type: 'qcm', img: 'images/conversion_kmh_ms.png', q: "Pour convertir des km/h en m/s, il faut…", options: ["Multiplier par 3,6", "Diviser par 3,6", "Ajouter 3,6", "Soustraire 3,6"], answer: "Diviser par 3,6", expl: "1 km/h = 1000 m / 3600 s = 1/3,6 m/s." },
    { type: 'qcm', img: 'images/formule_vitesse.png', q: "Quelle grandeur est calculée par la formule d / t ?", options: ["La distance", "La durée", "La vitesse", "La masse"], answer: "La vitesse", expl: "v = d / t." },
    { type: 'qcm', img: 'images/route_descente_panneau.svg', q: "Ce panneau signale une descente dangereuse. Il faut être vigilant car…", options: ["La voiture va s'arrêter toute seule", "La distance de freinage risque d'augmenter", "La vitesse va diminuer", "Les pneus vont mieux adhérer"], answer: "La distance de freinage risque d'augmenter", expl: "Dans une descente, la voiture prend de la vitesse et freine moins bien." },
    { type: 'qcm', img: 'images/distance_reaction_freinage.png', q: "La flèche A représente la distance de …, la flèche B la distance de …", options: ["Freinage / Réaction", "Réaction / Freinage", "Arrêt / Réaction", "Réaction / Arrêt"], answer: "Réaction / Freinage", expl: "On réagit d'abord (A), puis on freine (B) ; A + B = distance d'arrêt." },
    { type: 'qcm', img: 'images/graphe_distance_arret.png', q: "D'après ce graphique, quelle est environ la distance d'arrêt à 100 km/h ?", options: ["25 m", "50 m", "75 m", "100 m"], answer: "50 m", expl: "On part de 100 km/h sur l'axe horizontal, on monte jusqu'à la courbe et on lit environ 50 m." },

    // -- Exercices de synthèse --
    { type: 'synthese', contexte: "Une moto roule à 72 km/h. Son conducteur a un temps de réaction de 1 s.", questions: [
      { type: 'num', q: "Quelle est la vitesse de la moto en m/s ?", unit: "m/s", answer: 20, expl: "72 / 3,6 = 20 m/s." },
      { type: 'num', q: "Quelle distance parcourt la moto pendant le temps de réaction ?", unit: "m", answer: 20, expl: "d = 20 × 1 = 20 m." },
    ]},
    { type: 'synthese', contexte: "Un train à grande vitesse parcourt 300 km en 1 h 15 min (soit 1,25 h).", questions: [
      { type: 'num', q: "Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 240, expl: "v = 300 / 1,25 = 240 km/h." },
      { type: 'num', q: "À cette vitesse, quelle distance parcourt-il en 30 minutes (0,5 h) ?", unit: "km", answer: 120, expl: "d = 240 × 0,5 = 120 km." },
    ]},
    { type: 'synthese', contexte: "Une voiture A roule à 50 km/h. Une voiture B roule à 100 km/h.", questions: [
      { type: 'qcm', q: "La distance de freinage de la voiture B est environ … fois plus grande que celle de la voiture A.", options: ["1,5", "2", "3", "4"], answer: "4", expl: "La vitesse double, la distance de freinage est multipliée par 2² = 4." },
      { type: 'qcm', q: "La distance de réaction de la voiture B est … fois plus grande que celle de la voiture A.", options: ["1,5", "2", "3", "4"], answer: "2", expl: "La distance de réaction est proportionnelle à la vitesse : × 2." },
    ]},
    { type: 'synthese', contexte: "Un cycliste met 2 h 30 min (2,5 h) pour faire un aller-retour de 60 km au total.", questions: [
      { type: 'num', q: "Quelle est sa vitesse moyenne sur l'ensemble du parcours ?", unit: "km/h", answer: 24, expl: "v = 60 / 2,5 = 24 km/h." },
      { type: 'qcm', q: "L'aller a été plus rapide que le retour (à cause du vent). Sa vitesse moyenne à l'aller était…", options: ["Inférieure à 24 km/h", "Égale à 24 km/h", "Supérieure à 24 km/h"], answer: "Supérieure à 24 km/h", expl: "Si l'aller est plus rapide que la moyenne, sa vitesse dépasse 24 km/h." },
    ]},
  ],

  /* ======================= NIVEAU DIFFICILE (40) ======================= */
  difficile: [
    { type: 'num', q: "Un véhicule roule à 108 km/h (30 m/s). Son temps de réaction est de 1 s et sa distance de freinage de 70 m. Quelle est sa distance d'arrêt ?", unit: "m", answer: 100, expl: "Distance de réaction = 30 × 1 = 30 m ; distance d'arrêt = 30 + 70 = 100 m." },
    { type: 'num', q: "Un train à grande vitesse parcourt 450 km en 2 heures. Quelle est sa vitesse moyenne ?", unit: "km/h", answer: 225, expl: "v = 450 / 2 = 225 km/h." },
    { type: 'qcm', q: "Sur route mouillée, on estime que la distance de freinage est multipliée par environ…", options: ["1,2", "1,5", "2", "4"], answer: "2", expl: "Sur route mouillée, on compte environ le double de la distance sur route sèche." },
    { type: 'num', q: "Convertir 50 m/s en km/h.", unit: "km/h", answer: 180, expl: "50 × 3,6 = 180 km/h." },
    { type: 'qcm', q: "Sur une route enneigée ou verglacée, le principal facteur qui limite le freinage est…", options: ["La puissance des freins", "La masse du véhicule", "L'adhérence entre le pneu et la route", "La température de l'air"], answer: "L'adhérence entre le pneu et la route", expl: "Même avec de bons freins, la voiture glisse si les pneus n'adhèrent pas." },
    { type: 'num', q: "Un conducteur a un temps de réaction de 0,8 s. À 126 km/h (35 m/s), quelle est sa distance de réaction ?", unit: "m", answer: 28, expl: "d = 35 × 0,8 = 28 m." },
    { type: 'num', q: "Un véhicule roule à 144 km/h. Quelle est sa vitesse en m/s ?", unit: "m/s", answer: 40, expl: "144 / 3,6 = 40 m/s." },
    { type: 'num', q: "Un avion vole à 900 km/h pendant 4 h 30 min (4,5 h). Quelle distance parcourt-il ?", unit: "km", answer: 4050, expl: "d = 900 × 4,5 = 4050 km." },
    { type: 'qcm', q: "Le facteur le plus important pour réduire sa distance de réaction est…", options: ["Avoir de bons pneus", "Avoir de bons freins", "Être attentif et reposé", "Laver sa voiture"], answer: "Être attentif et reposé", expl: "Un conducteur attentif et reposé réagit plus vite. Pneus et freins agissent sur le freinage, pas sur la réaction." },
    { type: 'num', q: "À 50 km/h, la distance de freinage d'une voiture est de 14 m. Quelle est-elle à 100 km/h ?", unit: "m", answer: 56, expl: "La vitesse double, la distance de freinage est multipliée par 4 : 14 × 4 = 56 m." },
    { type: 'qcm', q: "Doubler la vitesse multiplie la distance de réaction par 2 et la distance de freinage par 4. La distance d'arrêt est donc multipliée par…", options: ["Moins de 2", "Exactement 2", "Un nombre entre 2 et 4", "Plus de 4"], answer: "Un nombre entre 2 et 4", expl: "La distance d'arrêt est la somme des deux : son facteur est compris entre 2 et 4." },
    { type: 'qcm', q: "Dans une montée, à même vitesse initiale, la distance de freinage a tendance à…", options: ["Augmenter", "Diminuer", "Rester la même", "Devenir nulle"], answer: "Diminuer", expl: "Dans une montée, le poids freine aussi la voiture." },
    { type: 'num', q: "Un conducteur très attentif a un temps de réaction de 0,7 s. À 90 km/h (25 m/s), quelle est sa distance de réaction ?", unit: "m", answer: 17.5, expl: "d = 25 × 0,7 = 17,5 m." },
    { type: 'qcm', q: "Le système ABS (anti-blocage des roues) permet surtout de…", options: ["Réduire beaucoup la distance de freinage sur sol sec", "Garder le contrôle de la direction pendant un freinage d'urgence", "Augmenter la puissance du moteur", "Freiner automatiquement"], answer: "Garder le contrôle de la direction pendant un freinage d'urgence", expl: "Les roues ne se bloquent pas : le conducteur peut encore tourner le volant." },
    { type: 'num', q: "Un élève parcourt 1,2 km en 20 minutes. Quelle est sa vitesse moyenne en m/s ?", unit: "m/s", answer: 1, expl: "1,2 km = 1200 m ; 20 min = 1200 s ; v = 1200 / 1200 = 1 m/s." },
    { type: 'num', q: "Le son se propage dans l'air à 340 m/s. On entend le tonnerre 3 s après avoir vu l'éclair. À quelle distance est l'orage ?", unit: "m", answer: 1020, expl: "La lumière arrive presque instantanément ; d = 340 × 3 = 1020 m." },
    { type: 'num', q: "La lumière se propage à 300 000 km/s. La distance Soleil-Terre est de 150 000 000 km. Combien de temps met la lumière du Soleil pour nous parvenir ?", unit: "s", answer: 500, expl: "t = 150 000 000 / 300 000 = 500 s (environ 8 min 20 s)." },
    { type: 'num', q: "À cause de l'alcool, le temps de réaction d'un conducteur passe de 1 s à 2 s. Il roule à 25 m/s. De combien de mètres sa distance de réaction augmente-t-elle ?", unit: "m", answer: 25, expl: "Avant : 25 × 1 = 25 m. Après : 25 × 2 = 50 m. Augmentation : 25 m." },
    { type: 'qcm', q: "Le temps de réaction d'un conducteur attentif est d'environ…", options: ["0,01 s", "1 s", "10 s", "1 min"], answer: "1 s", expl: "On retient en général environ 1 s pour un conducteur attentif." },
    { type: 'qcm', q: "Une voiture roule à 54 km/h et une moto à 15 m/s. Laquelle est la plus rapide ?", options: ["La voiture", "La moto", "Elles ont la même vitesse", "On ne peut pas comparer"], answer: "Elles ont la même vitesse", expl: "54 / 3,6 = 15 m/s : les deux vitesses sont égales." },
    { type: 'num', q: "Un camion roule à 80 km/h pendant 45 minutes. Quelle distance parcourt-il ?", unit: "km", answer: 60, expl: "45 min = 0,75 h ; d = 80 × 0,75 = 60 km." },

    // -- Questions avec image --
    { type: 'qcm', img: 'images/graphe_distance_arret.png', q: "Ce graphique montre que la distance d'arrêt augmente … que proportionnellement à la vitesse.", options: ["Moins vite", "Exactement", "Plus vite", "Inversement"], answer: "Plus vite", expl: "La courbe monte de plus en plus fort : ce n'est pas une droite." },
    { type: 'qcm', img: 'images/telephone_volant.png', q: "L'utilisation du téléphone au volant augmente dangereusement…", options: ["La distance de freinage seulement", "La distance de réaction seulement", "La distance de réaction, et elle gêne aussi le freinage", "Uniquement la consommation"], answer: "La distance de réaction, et elle gêne aussi le freinage", expl: "Le conducteur distrait réagit plus tard et freine souvent moins bien." },
    { type: 'qcm', img: 'images/pneus_lisses.png', q: "Des pneus usés (lisses) augmentent surtout la distance de freinage sur un sol…", options: ["Sec", "Mouillé", "Neigeux", "Mouillé et neigeux"], answer: "Mouillé et neigeux", expl: "Les rainures du pneu évacuent l'eau ; sans elles, le pneu glisse." },
    { type: 'qcm', img: 'images/calcul_temps_trajet.png', q: "Pour calculer la durée t d'un trajet de distance d à la vitesse moyenne v, on utilise :", options: ["t = d × v", "t = v / d", "t = d / v", "t = d + v"], answer: "t = d / v", expl: "De v = d / t on tire t = d / v." },
    { type: 'qcm', img: 'images/comparaison_vitesses_impact.png', q: "Un choc à 90 km/h est bien plus violent qu'à 60 km/h. Les dégâts dépendent fortement de…", options: ["La couleur", "La masse seulement", "La vitesse (au carré)", "L'heure"], answer: "La vitesse (au carré)", expl: "L'énergie du véhicule dépend du carré de sa vitesse." },
    { type: 'qcm', img: 'images/graphe_distance_temps.svg', q: "Ce graphique montre la distance parcourue par un cycliste en fonction du temps. Quelle est sa vitesse ?", options: ["2 m/s", "5 m/s", "10 m/s", "300 m/s"], answer: "5 m/s", expl: "Il parcourt 300 m en 60 s : v = 300 / 60 = 5 m/s. La droite indique un mouvement uniforme." },

    // -- Exercices de synthèse --
    { type: 'synthese', contexte: "Une voiture roule à 120 km/h sur l'autoroute. Le conducteur voit soudain un obstacle.", questions: [
      { type: 'num', q: "Convertir 120 km/h en m/s (arrondir au dixième).", unit: "m/s", answer: 33.3, expl: "120 / 3,6 ≈ 33,3 m/s." },
      { type: 'num', q: "Son temps de réaction est de 1,1 s. Quelle distance parcourt-il avant de commencer à freiner ? (arrondir à l'unité)", unit: "m", answer: 37, expl: "d = 33,3 × 1,1 ≈ 36,7 m, soit environ 37 m." },
    ]},
    { type: 'synthese', contexte: "Un train A parcourt 600 km en 4 h. Un train B parcourt la même distance en 3 h.", questions: [
      { type: 'num', q: "Quelle est la vitesse moyenne du train A ?", unit: "km/h", answer: 150, expl: "vA = 600 / 4 = 150 km/h." },
      { type: 'num', q: "Quelle est la vitesse moyenne du train B ?", unit: "km/h", answer: 200, expl: "vB = 600 / 3 = 200 km/h." },
    ]},
    { type: 'synthese', contexte: "Un véhicule roule à 90 km/h (25 m/s). Sa distance de réaction est de 25 m.", questions: [
      { type: 'num', q: "Quel est le temps de réaction du conducteur ?", unit: "s", answer: 1, expl: "t = d / v = 25 / 25 = 1 s." },
      { type: 'num', q: "Sa distance de freinage est de 50 m. Quelle est sa distance d'arrêt ?", unit: "m", answer: 75, expl: "25 + 50 = 75 m." },
    ]},
    { type: 'synthese', contexte: "Une voiture met 20 min pour parcourir 15 km en ville, puis 45 min pour parcourir 90 km sur l'autoroute.", questions: [
      { type: 'num', q: "Quelle est la distance totale parcourue ?", unit: "km", answer: 105, expl: "15 + 90 = 105 km." },
      { type: 'num', q: "Quelle est la vitesse moyenne sur tout le trajet ? (arrondir au dixième)", unit: "km/h", answer: 96.9, expl: "Durée totale = 65 min = 65/60 h ; v = 105 × 60 / 65 ≈ 96,9 km/h." },
    ]},
    { type: 'synthese', contexte: "Une voiture parcourt 30 km à 60 km/h, puis encore 30 km à 90 km/h.", questions: [
      { type: 'num', q: "Quelle est la durée totale du trajet, en minutes ?", unit: "min", answer: 50, expl: "30/60 = 0,5 h = 30 min ; 30/90 = 1/3 h = 20 min ; total 50 min." },
      { type: 'num', q: "Quelle est la vitesse moyenne sur tout le trajet ?", unit: "km/h", answer: 72, expl: "v = 60 km / (50/60 h) = 72 km/h." },
      { type: 'qcm', q: "La vitesse moyenne est-elle égale à la moyenne (60 + 90) / 2 = 75 km/h ?", options: ["Oui", "Non, elle est plus petite", "Non, elle est plus grande"], answer: "Non, elle est plus petite", expl: "La voiture passe plus de temps à 60 km/h qu'à 90 km/h : la moyenne vaut 72 km/h." },
    ]},
    { type: 'synthese', contexte: "Un conducteur roule à 108 km/h sur l'autoroute Rabat–Casablanca. Il regarde son téléphone pendant 3 s.", questions: [
      { type: 'num', q: "Quelle est sa vitesse en m/s ?", unit: "m/s", answer: 30, expl: "108 / 3,6 = 30 m/s." },
      { type: 'num', q: "Quelle distance parcourt-il sans regarder la route ?", unit: "m", answer: 90, expl: "d = 30 × 3 = 90 m : presque la longueur d'un terrain de football !" },
    ]},
  ],
};

/* Mélange un tableau sur place (algorithme de Fisher-Yates). */
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}
